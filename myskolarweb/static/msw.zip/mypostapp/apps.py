from django.apps import AppConfig

class MypostappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mypostapp'
